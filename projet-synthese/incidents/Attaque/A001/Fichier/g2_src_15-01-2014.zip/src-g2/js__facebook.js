  window.fbAsyncInit=function(){
    FB.init({
                appId:"349376671873474",
                status:true,
                cookie:true,
                xfbml:true,
                oauth:true
            })
    };

    $("#facebook_login").click(function(){
        FB.login(function(e){
            if(e.authResponse){
                window.location.href ='connexion/fb'; 
            }else{

            }
        },{scope:"email"})});

    $("#facebook_logout").click(function() {
        FB.logout(function(response) {
          if(e.authResponse) {
                window.location.href ='deconnexion/fb';                     
          }
        });
    })
  // Load the SDK asynchronously
  $(document).ready(function() {
     // If we've already installed the SDK, we're done
     if (document.getElementById('facebook-jssdk')) {return;}

     // Get the first script element, which we'll use to find the parent node
     var firstScriptElement = document.getElementsByTagName('script')[0];

     // Create a new script element and set its id
     var facebookJS = document.createElement('script'); 
     facebookJS.id = 'facebook-jssdk';

     // Set the new script's source to the source of the Facebook JS SDK
     facebookJS.src = 'http://connect.facebook.net/fr_FR/all.js';

     // Insert the Facebook JS SDK into the DOM
     firstScriptElement.parentNode.insertBefore(facebookJS, firstScriptElement);
   });