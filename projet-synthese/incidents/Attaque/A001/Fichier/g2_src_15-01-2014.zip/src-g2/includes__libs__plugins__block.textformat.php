
<!DOCTYPE html>
<html lang="fr">
  <head>
    <base href="/">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="TuxStarBeneMomo">
        <!-- <link rel="shortcut icon" href="assets/ico/favicon.png"> -->
    <title>Interface mediawiki</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/footer.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->    
        <script src="js/jquery.js"></script>
    <script src="//tinymce.cachefly.net/4.0/tinymce.min.js"></script>
    <script>
        tinymce.init({
            selector: "textarea",
            plugins: [
                "advlist autolink lists link charmap",
                "searchreplace visualblocks code fullscreen",
                "insertdatetime media contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link"
        });
    </script>
  </head>

  <body>
    <div id="fb-root"></div>
    <!-- contenu principal -->
    <div class="container" style="margin-top:30px;">
        <!-- Static navbar -->
      <div class="navbar navbar-default" style="margin-bottom:30px;">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/accueil">Wikeditor</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="/accueil">Accueil</a></li>
            <li><a href="/how-to.html">How to</a></li>
                                  </ul>
                      <div class="navbar-collapse collapse">
                <form class="navbar-form navbar-right" method="post" action="/#">
                    <div class="form-group">
                        <input type="text" placeholder="Pseudo" name="username" class="form-control" pattern="^[a-zA-Z0-9.-_]{4,100}$" required>
                        </div>
                        <div class="form-group">
                        <input type="password" placeholder="Password" name="password" class="form-control" pattern="^(.){8,20}$" required>
                    </div>
                    <button type="submit" class="btn btn-success">Connexion</button>
                    <a href="/inscription" type="submit" class="btn btn-info">Inscription</a>
                    <style>
                        #facebook_login { cursor: pointer;opacity: 0.7; }
                        #facebook_login:hover { opacity: 1; }
                    </style>
                    <img src="images/fb.png" alt="fb" id="facebook_login">
                </form>
            </div><!--/.navbar-collapse -->
                  </div><!--/.nav-collapse -->
      </div>


            
                  
    
    <!-- content -->
    

        <div class="jumbotron">
            <h1>404</h1>
            <p>Breaking all rules !</p>
            <p><a href="#">La FAQ</a> est là pour vous renseigner et vous guider.</p>
            <p>
                <a class="btn btn-lg btn-primary" href="/redaction/">Commencer à rédiger &raquo;</a>
            </p>
        </div>


 

    </div>

    <!-- bas de page -->         
    
    <div class="container" style="margin-top:30px;">
        <div style="padding:5px;padding-left:60px;padding-right:60px;background-color:#eee;border-radius:6px;">
            <p class="text-muted credit pull-left">                
                <a href="/accueil">accueil</a> | <a href="/accueil.html">sitemap</a>
            </p>   
            <p class="text-muted credit pull-right">
                © Tux Staross Benesai Momo
            </p> 
            <p style="clear:both"></p>     
            <p>Total requêtes : 1</p>
        </div>
    </div>
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/facebook.js?time=1389274712"></script>
    <script id="facebook-jssdk" src="http://connect.facebook.net/fr_FR/all.js"></script>
  </body>
</html>
Temps d'execution : 0.0111